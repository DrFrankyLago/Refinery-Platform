License
=======

The Refinery Platform license is very similar to the MIT License but contains an additional clause the prohibits the use of the
names of the copyright holders in most circumstances.

.. literalinclude:: ../LICENSE
