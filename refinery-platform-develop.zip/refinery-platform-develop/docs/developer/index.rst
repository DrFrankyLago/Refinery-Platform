.. include ../global.rst
.. _refinery-repository: http://www.github.com/parklab/refinery-platform

Developer Documentation
=======================

This section of the Refinery Platform documentation is intended for developers who are contributing to the Refinery core and extensions.

The source code for the Refinery Platform is available in the `repository`__.

__ refinery-repository_

.. toctree::
   :maxdepth: 2

   development_environment

* :ref:`genindex`
* :ref:`modindex`
