core Package
============

:mod:`admin` Module
-------------------

.. automodule:: core.admin
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`models` Module
--------------------

.. automodule:: core.models
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tasks` Module
-------------------

.. automodule:: core.tasks
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tests` Module
-------------------

.. automodule:: core.tests
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`views` Module
-------------------

.. automodule:: core.views
    :members:
    :undoc-members:
    :show-inheritance:

