data_set_manager Package
========================

:mod:`admin` Module
-------------------

.. automodule:: data_set_manager.admin
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`models` Module
--------------------

.. automodule:: data_set_manager.models
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tasks` Module
-------------------

.. automodule:: data_set_manager.tasks
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tests` Module
-------------------

.. automodule:: data_set_manager.tests
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`views` Module
-------------------

.. automodule:: data_set_manager.views
    :members:
    :undoc-members:
    :show-inheritance:

