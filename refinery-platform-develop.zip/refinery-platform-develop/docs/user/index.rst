.. include ../global.rst

User Documentation
==================

This section of the Refinery Platform documentation is intended for users of the web application.

.. toctree::
   :maxdepth: 2