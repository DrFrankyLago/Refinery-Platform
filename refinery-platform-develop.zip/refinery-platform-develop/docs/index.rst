Refinery Platform Documentation
===============================

The Refinery Platform documentation is split up into three major sections: one for users, one for administrators and one for developers.

.. toctree::
   :maxdepth: 2
   
   user/index   
   administrator/index
   developer/index
   license