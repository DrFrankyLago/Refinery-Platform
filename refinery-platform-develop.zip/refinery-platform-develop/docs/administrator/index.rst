.. include global.rst

Administrator Documentation
===========================

This section of the Refinery Platform documentation is intended for administrator of a Refinery instance.

.. toctree::
   :maxdepth: 2

   setup
   upgrade
   preparing_galaxy_workflows
   importing_galaxy_workflows
   add_new_genomebuild