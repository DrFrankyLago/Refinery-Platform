'''
Created on Apr 12, 2012

@author: rpark
'''
from django.contrib import admin
from analysis_manager.models import AnalysisStatus

admin.site.register(AnalysisStatus)
