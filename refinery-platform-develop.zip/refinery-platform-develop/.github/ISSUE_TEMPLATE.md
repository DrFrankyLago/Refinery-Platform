Commit: 

### Steps to reproduce
1. Version of browser and OS
2. Location of error produced (test site, locally in dev mode, locally in prod mode, etc)
3. Data set or file used
4. 

### Observed behavior
1. Console error (include traceback)
2. Server errors
3. Refinery log errors
4. Images or gifs

### Expected behavior
